# ruby-irc-bot
A simple IRC bot for educational purposes

The code is deliberatly kept simple, in order to be easy to understand. E.g. we don't use classes or single quotes for strings and we don't omit parentheses (apart from with `puts`) and so on.

This was developed to serve as a project for the participants of [Ruby Monstas Zürich](http://www.rubymonstas.ch).

Here's a list of IRC commands you could implement: [List of Internet Relay Chat commands](https://en.wikipedia.org/wiki/List_of_Internet_Relay_Chat_commands)
